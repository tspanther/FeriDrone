projekt se nahaja na github repozitoriju: https://github.com/tspanther/FeriDrone/tree/srds_oddaja
funkcionalnosti povezane z SRDS: https://github.com/tspanther/FeriDrone/tree/srds_oddaja/ST - programska oprema za MCU, skripte za dekodiranje, pripravo podatkov na PC
